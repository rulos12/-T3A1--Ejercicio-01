package t3a1;
import java.util.Scanner;
/** ** @author Raul */
public class T3A1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        procesar();// TODO code application logic here
    }
    public static void procesar(){
        Scanner scanner=new Scanner (System.in);
        Calificaciones calificaciones = new Calificaciones();
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.print("Apellido Paterno: ");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.print("Apellido Materno: ");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.print("Grupo: ");
        String gupo= scanner.nextLine();
        calificaciones.setGupo(gupo);
        
        System.out.print("Carrera: ");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.print("Nombre de la primera asignatura: ");
        String nombreAsignatura = scanner.nextLine();
        calificaciones.setNombreAsignatura(nombreAsignatura);  
        
        System.out.print("Nombre de la segunda asignatura: ");
        String nombreAsignatura2 = scanner.nextLine();
        calificaciones.setNombreAsignatura2(nombreAsignatura2);
        
        System.out.print("Calificación 1: ");
        int calificacion = scanner.nextInt();
        calificaciones.setCalificacion(calificacion);
        
        System.out.print("Calificación 2: ");
        int calificacion2 = scanner.nextInt();
        calificaciones.setCalificacion2(calificacion2);
        calificaciones.setPromedio(calificacion);
        
        System.out.println("Estudiante: "+ calificaciones.getNombre());
        System.out.println("Grupo: "+ calificaciones.getGupo()+"   "+"Carrera: "+calificaciones.getCarrera()+"\n");
        System.out.println("Asignatura"+"    "+"Calificación");
        System.out.println(calificaciones.getNombreAsignatura()+"          "+calificaciones.getCalificacion());
        System.out.println(calificaciones.getNombreAsignatura2()+"          "+calificaciones.getCalificacion2());
        System.out.println("Promedio: "+"   "+calificaciones.getPromedio());
        
        
        
        
    }
    
}
