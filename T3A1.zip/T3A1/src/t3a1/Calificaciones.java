package t3a1;
import java.util.Scanner;
/**** @author Raul*/
public class Calificaciones {
    private String nombre; 
    private String apellidoPaterno; 
    private String apellidoMaterno;
    private String gupo;
    private String carrera;
    private String nombreAsignatura;
    private int calificacion;
    private String nombreAsignatura2;
    private int calificacion2;
    private double promedio;

    public Calificaciones() { //Metodo constructor vacío
    }

    public Calificaciones(String nombre, String apellidoPaterno, String apellidoMaterno, String gupo, String carrera, String nombreAsignatura, int calificacion,String nombreAsignatura2, int calificacion2, double promedio) {
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.gupo = gupo;
        this.carrera = carrera;
        this.nombreAsignatura = nombreAsignatura;
        this.calificacion = calificacion;
        this.nombreAsignatura2 = nombreAsignatura2;
        this.calificacion2 = calificacion2;
        this.promedio = promedio;
    }
    

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public String getGupo() {
        return gupo;
    }

    public void setGupo(String gupo) {
        this.gupo = gupo;
    }

    public String getCarrera() {
        return carrera;
    }

    public void setCarrera(String carrera) {
        this.carrera = carrera;
    }

    public String getNombreAsignatura() {
        return nombreAsignatura;
    }
 
    public void setNombreAsignatura(String nombreAsignatura) {
        this.nombreAsignatura = nombreAsignatura;
    }
    public String getNombreAsignatura2() {
        return nombreAsignatura2;
    }
    public void setNombreAsignatura2(String nombreAsignatura2) {
        this.nombreAsignatura2 = nombreAsignatura2;
    }

    public int getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(int calificacion) {
        this.calificacion = calificacion;
    }
     public int getCalificacion2() {
        return calificacion2;
    }
    public void setCalificacion2(int calificacion2) {
        this.calificacion2 = calificacion2;
    }

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = (calificacion+calificacion2)/2;
    }

   
    
    
    
}
